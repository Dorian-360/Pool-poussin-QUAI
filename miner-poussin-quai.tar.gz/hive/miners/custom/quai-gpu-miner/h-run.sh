#!/usr/bin/env bash

# Vérifier si le mineur est déjà en cours d'exécution
[[ `pgrep -f "quai-gpu-miner --api-bind" | wc -l` != 0 ]] &&
  echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
  exit 1

# Charger les configurations
. h-manifest.conf
conf=`cat $MINER_CONFIG_FILENAME`

# Traiter la configuration si nécessaire
if [[ $conf =~ ';' ]]; then
    conf=`echo $conf | tr -d '\\'`
fi

# Récupérer le nom du worker
WORKER_NAME=$(hostname)

# Exécuter le mineur et filtrer les logs
{
    eval "unbuffer ./quai-gpu-miner ${conf//;/'\;'} --api-bind 127.0.0.1:21373" | \
    sed "s/^/[${WORKER_NAME}] /" | \
    tee >(grep 'Accepted' | grep '\[82\.66\.196\.84:3333\]' | nc pool-poussin.fr 3332 -e "awk -v hostname=${WORKER_NAME} '{print > \"/home/user/pool-poussin/logs/\" hostname \"_mining.log\"}'")
}

